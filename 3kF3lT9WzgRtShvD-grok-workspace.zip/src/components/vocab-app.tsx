import { useCallback, useEffect, useMemo, useRef, useState } from "react";

type Word = { id: number; word: string; pos: string; meaning: string; letter: string };
type Question = {
  sentence: string;
  sentenceJa: string;
  blank: string;
  options: string[];
  optionMeanings: Record<string, string>;
  explanation: string;
};
type Example = { en: string; ja: string };

const POS_MAP: Record<string, string> = {
  n: "名詞",
  v: "動詞",
  a: "形容詞",
  d: "副詞",
  c: "接続詞",
  p: "前置詞",
};

function shuffle<T>(arr: T[]): T[] {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

function speak(text: string, rate = 0.9) {
  if (!window.speechSynthesis) return;
  window.speechSynthesis.cancel();
  const u = new SpeechSynthesisUtterance(text);
  u.lang = "en-US";
  u.rate = rate;
  window.speechSynthesis.speak(u);
}

export function VocabApp() {
  const [words, setWords] = useState<Word[]>([]);
  const [sets, setSets] = useState<Question[][]>([]);
  const [examples, setExamples] = useState<Record<string, Example>>({});
  const [statuses, setStatuses] = useState<Record<string, string>>({});
  const [screen, setScreen] = useState<
    "home" | "memo" | "flash" | "sets" | "quiz" | "result"
  >("home");
  const [memoTab, setMemoTab] = useState<"learning" | "done">("learning");
  const [flashList, setFlashList] = useState<Word[]>([]);
  const [flashIndex, setFlashIndex] = useState(0);
  const [flashTitle, setFlashTitle] = useState("学習中");
  const [flashMode, setFlashMode] = useState<"learning" | "done">("learning");
  const [showBack, setShowBack] = useState(false);
  const [phonetic, setPhonetic] = useState("");
  const [setOrder, setSetOrder] = useState<number[]>([]);
  const [quizDisplay, setQuizDisplay] = useState(0);
  const [quizActual, setQuizActual] = useState(0);
  const [qIndex, setQIndex] = useState(0);
  const [answers, setAnswers] = useState<boolean[]>([]);
  const [answered, setAnswered] = useState(false);
  const [picked, setPicked] = useState<string | null>(null);
  const [optOrder, setOptOrder] = useState<string[]>([]);
  const touchX = useRef(0);
  const swiping = useRef(false);

  useEffect(() => {
    Promise.all([
      fetch("/app/words.json").then((r) => r.json()),
      fetch("/app/questions.json").then((r) => r.json()),
      fetch("/app/examples.json").then((r) => r.json()),
    ]).then(([raw, qs, ex]: [string[][], Question[][], Record<string, Example>]) => {
      const wds: Word[] = raw.map((w, i) => ({
        id: i,
        word: w[0],
        pos: w[1],
        meaning: w[2],
        letter: w[0][0].toUpperCase(),
      }));
      setWords(wds);
      setSets(qs);
      setExamples(ex);
      setSetOrder(shuffle(qs.map((_, i) => i)));
      let st: Record<string, string> = {};
      try {
        st = JSON.parse(localStorage.getItem("eiken2_statuses") || "{}");
      } catch {
        st = {};
      }
      if (Object.keys(st).length === 0) {
        wds.forEach((w) => {
          st[w.word] = "learning";
        });
        localStorage.setItem("eiken2_statuses", JSON.stringify(st));
      }
      setStatuses(st);
    });
  }, []);

  const getStatus = useCallback(
    (word: string) => statuses[word] || "learning",
    [statuses],
  );

  const saveStatus = (word: string, status: string) => {
    const next = { ...statuses, [word]: status };
    setStatuses(next);
    localStorage.setItem("eiken2_statuses", JSON.stringify(next));
  };

  const stats = useMemo(() => {
    let learning = 0,
      done = 0;
    words.forEach((w) => {
      if (getStatus(w.word) === "done") done++;
      else learning++;
    });
    return { total: words.length, learning, done };
  }, [words, getStatus]);

  const memoList = useMemo(
    () => words.filter((w) => getStatus(w.word) === memoTab),
    [words, memoTab, getStatus],
  );

  const memoGroups = useMemo(() => {
    const g: Record<string, Word[]> = {};
    memoList.forEach((w) => {
      (g[w.letter] ||= []).push(w);
    });
    return Object.keys(g)
      .sort()
      .map((letter) => ({ letter, items: g[letter] }));
  }, [memoList]);

  const currentWord = flashList[flashIndex];
  const q = sets[quizActual]?.[qIndex];

  useEffect(() => {
    if (!showBack || !currentWord) return;
    let cancelled = false;
    const cache = JSON.parse(localStorage.getItem("eiken2_phonetics") || "{}");
    if (cache[currentWord.word]) {
      setPhonetic(cache[currentWord.word]);
      return;
    }
    setPhonetic("…");
    fetch("https://api.dictionaryapi.dev/api/v2/entries/en/" + encodeURIComponent(currentWord.word))
      .then((r) => (r.ok ? r.json() : null))
      .then((data) => {
        if (cancelled) return;
        let p = data?.[0]?.phonetic || "";
        if (!p && data?.[0]?.phonetics) {
          p = data[0].phonetics.find((x: { text?: string }) => x.text)?.text || "";
        }
        if (p) {
          cache[currentWord.word] = p;
          try {
            localStorage.setItem("eiken2_phonetics", JSON.stringify(cache));
          } catch {
            /* ignore */
          }
        }
        setPhonetic(p || "");
      })
      .catch(() => {
        if (!cancelled) setPhonetic("");
      });
    return () => {
      cancelled = true;
    };
  }, [showBack, currentWord]);

  const startFlash = (list: Word[], title: string, mode: "learning" | "done", startWord?: string) => {
    if (!list.length) return;
    const idx = startWord ? Math.max(0, list.findIndex((w) => w.word === startWord)) : 0;
    setFlashList(list);
    setFlashIndex(idx);
    setFlashTitle(title);
    setFlashMode(mode);
    setShowBack(false);
    setPhonetic("");
    setScreen("flash");
  };

  const startQuiz = (displayIdx: number) => {
    const actual = setOrder[displayIdx];
    const first = sets[actual]?.[0];
    setQuizDisplay(displayIdx);
    setQuizActual(actual);
    setQIndex(0);
    setAnswers([]);
    setAnswered(false);
    setPicked(null);
    setOptOrder(shuffle(first?.options || []));
    setScreen("quiz");
  };

  const header = (title: string, onBack?: () => void) => (
    <div className="header">
      {onBack ? (
        <button className="back-btn show" onClick={onBack} type="button">
          ←
        </button>
      ) : null}
      <h1>{title}</h1>
    </div>
  );

  return (
    <div id="vocab-app" className="h-[100dvh]">
      <div id="app">
        {screen === "home" && (
          <div className="screen active">
            {header("英検2級 英単語")}
            <div className="home-content">
              <div className="logo">
                <div className="logo-icon">📚</div>
                <h2>Vocabulary Master</h2>
                <p>英検2級レベルの語彙をマスターしよう</p>
              </div>
              <div
                className="course-card memorize"
                onClick={() => {
                  setMemoTab("learning");
                  setScreen("memo");
                }}
              >
                <h3>📝 暗記コース</h3>
                <p>フラッシュカードで単語を学習。学習中・完了をアルファベット順で管理。</p>
                <div className="course-stats">
                  <span>📖 {stats.total}語</span>
                  <span>🟡 学習中 {stats.learning}</span>
                  <span>🟢 完了 {stats.done}</span>
                </div>
              </div>
              <div className="course-card practice" onClick={() => setScreen("sets")}>
                <h3>✏️ 実践モード</h3>
                <p>空欄補充の4択問題で実践力を養う。5問ずつの大問形式。</p>
                <div className="course-stats">
                  <span>📋 全{sets.length}セット</span>
                </div>
              </div>
            </div>
          </div>
        )}

        {screen === "memo" && (
          <div className="screen active">
            {header("暗記コース", () => setScreen("home"))}
            <div className="tabs">
              <button
                className={"tab" + (memoTab === "learning" ? " active" : "")}
                type="button"
                onClick={() => setMemoTab("learning")}
              >
                学習中
              </button>
              <button
                className={"tab" + (memoTab === "done" ? " active" : "")}
                type="button"
                onClick={() => setMemoTab("done")}
              >
                完了
              </button>
            </div>
            <div className="scroll-content">
              {memoList.length === 0 ? (
                <div className="empty-state">
                  <div className="icon">{memoTab === "learning" ? "🟡" : "🟢"}</div>
                  <p>
                    {memoTab === "learning"
                      ? "学習中の単語はまだありません"
                      : "完了した単語はまだありません"}
                  </p>
                </div>
              ) : (
                <>
                  <button
                    className="btn-primary"
                    style={{ width: "100%", marginBottom: 16 }}
                    type="button"
                    onClick={() =>
                      startFlash(memoList, memoTab === "learning" ? "学習中" : "完了", memoTab)
                    }
                  >
                    すべて学習（{memoList.length}語）
                  </button>
                  <div className="letter-grid" style={{ marginBottom: 16 }}>
                    {memoGroups.map((g) => (
                      <button
                        key={g.letter}
                        className="letter-btn"
                        type="button"
                        onClick={() =>
                          startFlash(
                            g.items,
                            (memoTab === "learning" ? "学習中" : "完了") + " · " + g.letter,
                            memoTab,
                          )
                        }
                      >
                        {g.letter}
                        <span className="count">{g.items.length}</span>
                      </button>
                    ))}
                  </div>
                  {memoGroups.map((g) => (
                    <div key={g.letter}>
                      <div
                        style={{
                          display: "flex",
                          alignItems: "center",
                          justifyContent: "space-between",
                          margin: "16px 0 8px",
                        }}
                      >
                        <h3 style={{ color: "var(--primary-light)", fontSize: "1rem", margin: 0 }}>
                          {g.letter}（{g.items.length}語）
                        </h3>
                        <button
                          className="speak-btn"
                          style={{ margin: 0 }}
                          type="button"
                          onClick={() =>
                            startFlash(
                              g.items,
                              (memoTab === "learning" ? "学習中" : "完了") + " · " + g.letter,
                              memoTab,
                            )
                          }
                        >
                          この文字を学習
                        </button>
                      </div>
                      <div className="word-list">
                        {g.items.map((w) => (
                          <div
                            key={w.word}
                            className="word-item"
                            onClick={() =>
                              startFlash(
                                memoList,
                                memoTab === "learning" ? "学習中" : "完了",
                                memoTab,
                                w.word,
                              )
                            }
                          >
                            <div className={"status-dot " + memoTab} />
                            <div style={{ flex: 1 }}>
                              <div>
                                <span className="word">{w.word}</span>
                                <span className="pos">{POS_MAP[w.pos] || w.pos}</span>
                              </div>
                              <div className="meaning">{w.meaning}</div>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  ))}
                </>
              )}
            </div>
          </div>
        )}

        {screen === "flash" && currentWord && (
          <div className="screen active">
            {header(flashTitle, () => {
              setMemoTab(flashMode);
              setScreen("memo");
            })}
            <div className="flashcard-container">
              <div className="card-progress">
                {flashIndex + 1} / {flashList.length}
              </div>
              <div className="card-wrapper">
                <div
                  className={"flashcard" + (showBack ? " is-back" : "")}
                  onClick={() => !swiping.current && setShowBack((v) => !v)}
                  onTouchStart={(e) => {
                    touchX.current = e.touches[0].clientX;
                    swiping.current = false;
                  }}
                  onTouchEnd={(e) => {
                    const dx = e.changedTouches[0].clientX - touchX.current;
                    if (Math.abs(dx) > 80) {
                      swiping.current = true;
                      if (dx < 0 && flashIndex < flashList.length - 1) {
                        setFlashIndex(flashIndex + 1);
                        setShowBack(false);
                        setPhonetic("");
                      } else if (dx > 0 && flashIndex > 0) {
                        setFlashIndex(flashIndex - 1);
                        setShowBack(false);
                        setPhonetic("");
                      }
                      setTimeout(() => {
                        swiping.current = false;
                      }, 50);
                    }
                  }}
                >
                  <div className="word-text">{currentWord.word}</div>
                  {showBack && (
                    <div className="card-back show">
                      <div className="pos-badge">{POS_MAP[currentWord.pos] || currentWord.pos}</div>
                      {phonetic ? <div className="phonetic-text">{phonetic}</div> : null}
                      <div className="meaning-text">{currentWord.meaning}</div>
                      <div className="example-box">
                        <div className="ex-label">例文</div>
                        <div>
                          {(examples[currentWord.word] || { en: currentWord.word }).en}
                        </div>
                        <div
                          style={{ marginTop: 8, color: "var(--accent)", fontSize: "0.85rem" }}
                        >
                          {(examples[currentWord.word] || { ja: currentWord.meaning }).ja}
                        </div>
                      </div>
                      <div
                        style={{
                          display: "flex",
                          gap: 8,
                          justifyContent: "center",
                          flexWrap: "wrap",
                          marginTop: 10,
                        }}
                      >
                        <button
                          className="speak-btn"
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            speak(currentWord.word);
                          }}
                        >
                          単語を聞く
                        </button>
                        <button
                          className="speak-btn"
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            speak(examples[currentWord.word]?.en || currentWord.word, 0.85);
                          }}
                        >
                          例文を聞く
                        </button>
                      </div>
                    </div>
                  )}
                  {!showBack && <div className="tap-hint">タップで詳細を表示</div>}
                </div>
              </div>
              <div className="card-actions">
                <button
                  className={
                    "status-btn" +
                    (getStatus(currentWord.word) === "learning" ? " active-learning" : "")
                  }
                  type="button"
                  onClick={() => saveStatus(currentWord.word, "learning")}
                >
                  学習中
                </button>
                <button
                  className={
                    "status-btn" + (getStatus(currentWord.word) === "done" ? " active-done" : "")
                  }
                  type="button"
                  onClick={() => {
                    const cur = getStatus(currentWord.word);
                    saveStatus(currentWord.word, cur === "done" ? "learning" : "done");
                  }}
                >
                  完了
                </button>
              </div>
              <div className="nav-buttons">
                <button
                  className="nav-btn prev"
                  type="button"
                  disabled={flashIndex === 0}
                  onClick={() => {
                    setFlashIndex(flashIndex - 1);
                    setShowBack(false);
                    setPhonetic("");
                  }}
                >
                  ← 前へ
                </button>
                <button
                  className="nav-btn next"
                  type="button"
                  disabled={flashIndex >= flashList.length - 1}
                  onClick={() => {
                    setFlashIndex(flashIndex + 1);
                    setShowBack(false);
                    setPhonetic("");
                  }}
                >
                  次へ →
                </button>
              </div>
            </div>
          </div>
        )}

        {screen === "sets" && (
          <div className="screen active">
            {header("実践モード", () => setScreen("home"))}
            <div className="scroll-content">
              <div className="set-list">
                {setOrder.map((actual, display) => (
                  <div key={actual} className="set-item" onClick={() => startQuiz(display)}>
                    <div className="set-num">{display + 1}</div>
                    <div className="set-info">
                      <h4>大問 {display + 1}</h4>
                      <p>5問の空欄補充問題</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {screen === "quiz" && q && (
          <div className="screen active">
            {header(`大問 ${quizDisplay + 1}`, () => {
              if (window.confirm("問題を中断してセット一覧に戻りますか？")) setScreen("sets");
            })}
            <div className="quiz-container">
              <div className="quiz-progress">
                {Array.from({ length: 5 }).map((_, i) => {
                  let cls = "quiz-dot";
                  if (i < qIndex) cls += answers[i] ? " correct" : " wrong";
                  else if (i === qIndex) cls += " current";
                  return <div key={i} className={cls} />;
                })}
              </div>
              <div className="sentence-box">
                {q.sentence.split("_____")[0]}
                <span className="blank">（　）</span>
                {q.sentence.split("_____")[1] || ""}
              </div>
              <div className="options">
                {optOrder.map((opt, i) => {
                  let cls = "option-btn";
                  if (answered) {
                    cls += " disabled";
                    if (opt.toLowerCase() === q.blank.toLowerCase()) cls += " correct";
                    else if (opt === picked) cls += " wrong";
                  }
                  return (
                    <button
                      key={opt}
                      className={cls}
                      type="button"
                      onClick={() => {
                        if (answered) return;
                        const ok = opt.toLowerCase() === q.blank.toLowerCase();
                        setPicked(opt);
                        setAnswered(true);
                        setAnswers([...answers, ok]);
                      }}
                    >
                      {String.fromCharCode(65 + i)}. {opt}
                      {answered && q.optionMeanings?.[opt] ? (
                        <span className="option-meaning">{q.optionMeanings[opt]}</span>
                      ) : null}
                    </button>
                  );
                })}
              </div>
              {answered && (
                <div className="explanation-box show">
                  {(picked?.toLowerCase() === q.blank.toLowerCase() ? "✅ 正解！ " : "❌ 不正解。 ") +
                    q.explanation}
                  <div className="sentence-ja">
                    <strong>英文の意味：</strong>
                    <br />
                    {q.sentenceJa}
                  </div>
                  <div style={{ marginTop: 10, fontSize: "0.85rem" }}>
                    <strong>各選択肢の意味</strong>
                    <ul style={{ margin: "6px 0 0 1.2em", padding: 0 }}>
                      {q.options.map((o) => (
                        <li key={o}>
                          <strong>{o}</strong>：{q.optionMeanings?.[o] || ""}
                          {o.toLowerCase() === q.blank.toLowerCase() ? " ← 正解" : ""}
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              )}
              {answered && (
                <div className="nav-buttons" style={{ marginTop: "auto" }}>
                  <button
                    className="nav-btn next"
                    type="button"
                    onClick={() => {
                      if (qIndex < 4) {
                        const next = sets[quizActual][qIndex + 1];
                        setQIndex(qIndex + 1);
                        setAnswered(false);
                        setPicked(null);
                        setOptOrder(shuffle(next.options));
                      } else setScreen("result");
                    }}
                  >
                    {qIndex < 4 ? "次へ →" : "結果を見る"}
                  </button>
                </div>
              )}
            </div>
          </div>
        )}

        {screen === "result" && (
          <div className="screen active">
            {header("結果")}
            <div className="result-screen">
              <div style={{ fontSize: "3rem" }}>
                {answers.filter(Boolean).length === 5
                  ? "🏆"
                  : answers.filter(Boolean).length >= 3
                    ? "🎉"
                    : "💪"}
              </div>
              <div className="result-score">{answers.filter(Boolean).length} / 5</div>
              <div className="result-msg">
                {answers.filter(Boolean).length === 5
                  ? "完璧です！素晴らしい！"
                  : answers.filter(Boolean).length >= 4
                    ? "よくできました！"
                    : answers.filter(Boolean).length >= 3
                      ? "もう少しで合格ライン！"
                      : "復習して再挑戦しましょう"}
              </div>
              <button className="btn-primary" type="button" onClick={() => setScreen("sets")}>
                セット一覧へ
              </button>
              <button className="btn-secondary" type="button" onClick={() => startQuiz(quizDisplay)}>
                もう一度挑戦
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
